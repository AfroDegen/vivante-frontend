# Vivante Lagos — Frontend

A frontend-only storefront prototype for Vivante Lagos.

## Stack
- React + TypeScript + Vite
- Lucide icons
- Responsive CSS design system

## Run locally
```bash
npm install
npm run dev
```

Create a production build:
```bash
npm run build
npm run preview
```

## Brand direction
Purple, lilac and white. Editorial typography, generous whitespace, clear shopping paths, and a mobile-first layout.

## Scope
This repository is the customer-facing frontend only. No backend, inventory integration, payment processing, or live checkout is included yet.

## Before launch
1. Replace the temporary collection illustrations with approved product photography.
2. Replace the WhatsApp link in `src/App.tsx` with Vivante's actual business number.
3. Confirm product names, prices, delivery information, and policies with the client.
