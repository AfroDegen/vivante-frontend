import { ArrowRight, ArrowUpRight, Gift, Heart, Menu, PackageCheck, Sparkles, X } from 'lucide-react'
import { useState } from 'react'

const collections = [
  { name: 'The thoughtful edit', detail: 'Little gestures, beautifully put together.', price: 'From ₦25,000', tone: 'lavender', mark: '01' },
  { name: 'Celebration boxes', detail: 'Make their big moments feel even bigger.', price: 'From ₦45,000', tone: 'rose', mark: '02' },
  { name: 'Just because', detail: 'A reminder that someone is thinking of you.', price: 'From ₦18,000', tone: 'cream', mark: '03' },
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const closeMenu = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      <div className="announcement"><Sparkles size={13} /> A little thoughtfulness goes a long way <span>·</span> Made with care in Lagos</div>
      <header className="header">
        <a className="brand" href="#" aria-label="Vivante Lagos home">
          <img src="/brand/vivante-icon.png" alt="" className="brand-icon" />
          <span className="brand-name">vivante.</span>
        </a>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'} aria-label="Main navigation">
          <a href="#collections" onClick={closeMenu}>Shop gifts</a>
          <a href="#story" onClick={closeMenu}>Our story</a>
          <a href="#custom" onClick={closeMenu}>Custom boxes</a>
        </nav>
        <div className="header-actions">
          <a className="header-cta" href="#collections">Explore gifts <ArrowUpRight size={15} /></a>
          <button className="menu-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow"><span /> THE ART OF GIVING, REIMAGINED</p>
            <h1>Make someone<br /><em>feel remembered.</em></h1>
            <p className="hero-description">Thoughtful gifts and beautifully considered care packages for the people who make life mean a little more.</p>
            <div className="hero-buttons">
              <a className="button button-primary" href="#collections">Find their something <ArrowRight size={17} /></a>
              <a className="text-link" href="#story">Get to know us <ArrowUpRight size={16} /></a>
            </div>
            <div className="hero-note"><span className="note-icon"><Heart size={15} /></span><span>Curated with intention.<br /><strong>Delivered with care.</strong></span></div>
          </div>
          <div className="hero-art" role="img" aria-label="An illustrated gift box in soft lilac tones">
            <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
            <div className="art-card card-back"><span>FOR YOU</span></div>
            <div className="gift-box"><div className="gift-lid" /><div className="gift-ribbon ribbon-v" /><div className="gift-ribbon ribbon-h" /><div className="gift-bow"><i /><i /></div></div>
            <div className="art-caption"><span>THE VIVANTE EXPERIENCE</span><strong>A moment, made special.</strong></div>
            <div className="floating-stamp"><Gift size={22} /><span>GIFT<br/>WITH LOVE</span></div>
          </div>
        </section>

        <section className="promise-strip" aria-label="Our promise">
          <div><PackageCheck /><span>Thoughtfully curated</span></div><i /><div><Heart /><span>Made personal</span></div><i /><div><Sparkles /><span>Beautifully presented</span></div>
        </section>

        <section className="collections section-wrap" id="collections">
          <div className="section-heading"><div><p className="eyebrow"><span /> FIND THE RIGHT FEELING</p><h2>A good gift says<br /><em>what words can't.</em></h2></div><a className="text-link" href="#custom">View all collections <ArrowUpRight size={16}/></a></div>
          <div className="collection-grid">{collections.map((item) => <article className="collection-card" key={item.name}><div className={`collection-visual ${item.tone}`}><span className="collection-number">{item.mark}</span><div className="mini-gift"><div/><i/></div><span className="visual-word">vivante.</span></div><div className="collection-info"><div><h3>{item.name}</h3><p>{item.detail}</p></div><span className="price">{item.price}</span></div><a className="card-link" href="#custom" aria-label={`Enquire about ${item.name}`}><ArrowUpRight /></a></article>)}</div>
        </section>

        <section className="story" id="story"><div className="story-mark">v.</div><div className="story-copy"><p className="eyebrow"><span /> A NOTE FROM VIVANTE</p><h2>It's never just<br />about the <em>gift.</em></h2><p>It's the pause in someone's day. The unexpected smile. The quiet reminder that they matter. We make gifting feel as special as the person receiving it.</p><a className="text-link" href="#custom">Discover our approach <ArrowUpRight size={16}/></a></div><div className="story-side"><span>01 — 03</span><strong>Thought<br/>behind<br/><em>every detail.</em></strong></div></section>

        <section className="custom-cta section-wrap" id="custom"><div><p className="eyebrow"><span /> SOMETHING MORE PERSONAL</p><h2>Have someone<br />special in mind?</h2><p>Tell us a little about them. We'll help you put together something they'll remember.</p></div><a className="button button-light" href="https://wa.me/?text=Hello%20Vivante%2C%20I%27d%20like%20to%20create%20a%20custom%20gift%20box.">Let's make it personal <ArrowUpRight size={17}/></a></section>
      </main>

      <footer className="footer"><a className="brand footer-brand" href="#"><img src="/brand/vivante-icon.png" alt="" className="brand-icon"/><span className="brand-name">vivante.</span></a><span>Thoughtfully yours, Lagos.</span><span>© {new Date().getFullYear()} Vivante Lagos</span></footer>
    </div>
  )
}

export default App
